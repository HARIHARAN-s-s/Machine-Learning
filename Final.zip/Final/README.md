python packages needs to install

opencv-python, 
pycaw, 
pyautogui, 
autopy, 
mediapipe, 
numpy
