import cv2
import mediapipe as mp
from utils.hand_utils import detect_gesture
import pyautogui
import time

class GestureController:
    def __init__(self):
        self.cap = cv2.VideoCapture(0)
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(max_num_hands=1)
        self.cooldown = 0

    def start(self):
        while self.cap.isOpened():
            success, frame = self.cap.read()
            if not success:
                continue

            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = self.hands.process(frame_rgb)
            if results.multi_hand_landmarks:
                gesture = detect_gesture(results.multi_hand_landmarks[0])
                if gesture == "fist" and time.time() > self.cooldown:
                    pyautogui.press("space")
                    self.cooldown = time.time() + 2
                elif gesture == "peace" and time.time() > self.cooldown:
                    pyautogui.moveRel(10, 0)  # example: small right movement
                    self.cooldown = time.time() + 2

            cv2.imshow("Webcam", frame)
            if cv2.waitKey(5) & 0xFF == 27:
                break

        self.cap.release()
        cv2.destroyAllWindows()
