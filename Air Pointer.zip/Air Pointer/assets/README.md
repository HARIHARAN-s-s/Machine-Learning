# AirPointer

AirPointer is a real-time YouTube gesture controller combined with AI screenshot analysis. Users can control YouTube playback using hand gestures and send selected screen areas to GPT-based models for insight.

## Features
- Play/pause YouTube with fist gesture
- Draw on screen using peace sign
- Take screenshot of drawn region and send to ChatGPT/Gemini

## Requirements
```
pip install -r requirements.txt
```

## Run
```
python main.py
```

## License
MIT

