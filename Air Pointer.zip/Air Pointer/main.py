import sys
import threading
from PyQt5.QtWidgets import QApplication
from gesture_controller import GestureController
from overlay_gui import OverlayWindow

def run_gesture():
    """Runs the gesture controller loop in a background thread."""
    gesture = GestureController()
    gesture.start()

if __name__ == '__main__':
    # Create the QApplication before any QWidget
    app = QApplication(sys.argv)

    # Initialize and show overlay window
    overlay = OverlayWindow()
    overlay.show()

    # Start gesture controller in a separate daemon thread
    gesture_thread = threading.Thread(target=run_gesture, daemon=True)
    gesture_thread.start()

    # Enter the Qt event loop
    sys.exit(app.exec_())

