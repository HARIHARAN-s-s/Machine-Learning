
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton
from PyQt5.QtCore import Qt
import sys
from ai_screenshot_tool import take_ai_screenshot

class OverlayWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.X11BypassWindowManagerHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setGeometry(100, 100, 200, 100)

        btn = QPushButton('Screenshot', self)
        btn.clicked.connect(take_ai_screenshot)
        btn.setGeometry(50, 30, 100, 30)

    def start(self):
        app = QApplication(sys.argv)
        self.show()
        sys.exit(app.exec_())
