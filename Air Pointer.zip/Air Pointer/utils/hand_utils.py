def detect_gesture(landmarks):
    """
    Detects hand gesture based on landmark positions.
    Returns:
        - "fist" if all fingers are down
        - "peace" if index and middle fingers are up
        - "none" for unrecognized gestures
    """
    tip_ids = [4, 8, 12, 16, 20]  # Thumb, Index, Middle, Ring, Pinky tips
    fingers = []

    # Check thumb (x-axis)
    if landmarks.landmark[tip_ids[0]].x < landmarks.landmark[tip_ids[0] - 1].x:
        fingers.append(1)
    else:
        fingers.append(0)

    # Check other fingers (y-axis)
    for i in range(1, 5):
        if landmarks.landmark[tip_ids[i]].y < landmarks.landmark[tip_ids[i] - 2].y:
            fingers.append(1)
        else:
            fingers.append(0)

    if sum(fingers) == 0:
        return "fist"
    elif fingers[1] and fingers[2] and not fingers[3] and not fingers[4]:
        return "peace"
    else:
        return "none"

