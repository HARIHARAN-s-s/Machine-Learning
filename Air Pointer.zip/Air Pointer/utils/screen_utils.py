from PIL import ImageGrab

def capture_region(x, y, w, h):
    img = ImageGrab.grab(bbox=(x, y, x + w, y + h))
    img.save("screenshot.png")
    return "screenshot.png"
