import pyautogui
from utils.ai_client import send_to_ai
from PIL import ImageGrab


def take_ai_screenshot():
    region = pyautogui.screenshot(region=(100, 100, 400, 300))  # Example region
    region.save("capture.png")
    send_to_ai("capture.png")


